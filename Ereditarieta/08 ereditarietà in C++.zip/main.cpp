#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

#include "canvas.h"
#include "string.h"

/*
type_of_object parameter_1 parameter_2 ... parameter_n

rectangle 0 0 79 24 *
point 5 15 ?
circle 10 10 4 @
circle 70 10 4 @
line 40 15 40 20 |
*/

/*void draw_file(FILE *f, canvas *c)
{
	char type[30];
	while (fscanf(f, "%29s", type) == 1) {
		if (strcmp(type, "point") == 0) {
			int x, y;
			char ch;
			fscanf(f, "%d%d %c", &x, &y, &ch);
			canvas_set(c, x, y, ch);
		}
		else if (strcmp(type, "line") == 0) {
			int x0, y0, x1, y1;
			char ch;
			fscanf(f, "%d%d%d%d %c", &x0, &y0, &x1, &y1, &ch);
			canvas_line(c, x0, y0, x1, y1, ch);
		}
		else if (strcmp(type, "rectangle") == 0) {
			int x0, y0, x1, y1;
			char ch;
			fscanf(f, "%d%d%d%d %c", &x0, &y0, &x1, &y1, &ch);
			canvas_rectangle(c, x0, y0, x1, y1, ch);
		}
		else if (strcmp(type, "circle") == 0) {
			int xm, ym, r;
			char ch;
			fscanf(f, "%d%d%d %c", &xm, &ym, &r, &ch);
			canvas_circle(c, xm, ym, r, ch);
		}
	}
}*/

struct shape {
	int x_, y_;
	char c_;

	shape(int x, int y, char c) : x_(x), y_(y), c_(c) {}
	virtual ~shape() = default;

	virtual void draw(canvas* can) const {
		can->set(x_, y_, c_); // Non bellissimo
	}

	void printpos() const {
		printf("Posizione: %d,%d\n", this->x_, this->y_);
	}
};

struct line : public shape {
	int x2_, y2_;

	line(int x, int y, int x2, int y2, char c) : shape(x, y, c), x2_(x2), y2_(y2) {}

	void draw(canvas* can) const override {
		can->line(x_, y_, x2_, y2_, c_);
	}
};

struct rectangle : public shape {
	int x2_, y2_;

	rectangle(int x, int y, int x2, int y2, char c) : shape(x, y, c), x2_(x2), y2_(y2) {}

	void draw(canvas* can) const override {
		can->rectangle(x_, y_, x2_, y2_, c_);
	}
};

int main(void)
{
	canvas* c = new canvas(80, 25);
	/*
	FILE *f = fopen("drawing1.txt", "rt");
	if (f == NULL) return 1;
	draw_file(f, c);
	fclose(f);
	*/

	shape* arr[] = { 
		new rectangle(0, 0, 79, 24, '*'),
		new line(40, 15, 40, 20, '|'), 
	};
	size_t nshapes = 2;

	for (size_t i = 0; i < nshapes; ++i) {
		arr[i]->draw(c);
	}

	c->out(std::cout);

	for (size_t i = 0; i < nshapes; ++i) {
		delete arr[i];
	}
	delete c;
	return 0;
}